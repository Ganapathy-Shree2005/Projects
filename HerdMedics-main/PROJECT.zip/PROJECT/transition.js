document.addEventListener("DOMContentLoaded", function () { 
    document.body.classList.add("fade-in");
});
